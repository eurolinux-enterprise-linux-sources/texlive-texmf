_MenuProc = function() {;}
app.addMenuItem( { cName: "MenuProc", cUser: "Menu Procedure", cParent:
    "Tools", cExec: "_MenuProc()", nPos: 0 } );
app.addMenuItem( { cName: "newdoc", cUser: "New Document", cParent:
    "File", cExec: "app.newDoc()", nPos: 0 } );
